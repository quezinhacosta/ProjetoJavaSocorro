//Classe principal

import java.util.Scanner;

import classes.Estudante;
import classes.Labirinto;
import classes.negativas.PensamentoNegativo;
import classes.negativas.Perigo;
import classes.positivas.PequenaConquista;

public class Estagiario {

    public static void digitando(String texto, int tempo_atraso) {
        for (char c : texto.toCharArray()) {
            System.out.print(c);
            try {
                Thread.sleep(tempo_atraso);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
        }
        System.out.println();
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int op = 0;

        digitando("Bem-vindo(a) ao Campus Internus: A jornada de um universit�rio!", 30);

        while (true) {
            System.out.println("\nMenu Principal:");
            System.out.println("1 - Come�ar Jornada");
            System.out.println("2 - Sair");
            System.out.print("Escolha uma op��o: ");
            if (sc.hasNextInt()) {
                op = sc.nextInt();
            } else {
                sc.next();
                System.out.println("Op��o inv�lida. Por favor, insira um n�mero.");
                continue;
            }
            sc.nextLine();

            switch (op) {
                case 1:
                    digitando("Iniciando sua jornada de autoconhecimento...", 20);

                    System.out.print("Digite o nome do(a) estudante: ");
                    String nomeEstudante = sc.nextLine();

                    // Escolha de caracter�stica
                    System.out.println("\nEscolha uma caracter�stica que define seu personagem:");
                    System.out.println("1 - Maturidade (Conquistas melhores e narrativa mais reflexiva)");
                    System.out.println("2 - Ansiedade (Perigos mais intensos e narrativa mais tensa)");
                    System.out.println("3 - Sabedoria (Jogo mais f�cil)");
                    System.out.print("Digite o n�mero correspondente � caracter�stica: ");
                    int escolha = sc.nextInt();
                    sc.nextLine();

                    String caracteristica = "";
                    int confiancaInicial = 20;

                    switch (escolha) {
                        case 1:
                            caracteristica = "maturidade";
                            confiancaInicial += 10; // Conquistas dar�o mais confian�a
                            digitando("Voc� escolheu Maturidade. Sua jornada ser� profunda e suas conquistas mais significativas.", 30);
                            break;
                        case 2:
                            caracteristica = "ansiedade";
                            confiancaInicial -= 10; // Perigos mais fortes
                            digitando("Voc� escolheu Ansiedade. A jornada ser� tensa e os perigos mais desafiadores, mas voc� � forte!", 30);
                            break;
                        case 3:
                            caracteristica = "sabedoria";
                            confiancaInicial += 15; // Come�a mais preparado
                            digitando("Voc� escolheu Sabedoria. Sua experi�ncia o ajudar� a tomar decis�es mais acertadas no labirinto.", 30);
                            break;
                        default:
                            caracteristica = "neutra";
                            digitando("Nenhuma caracter�stica especial foi escolhida. Boa sorte na sua jornada!", 30);
                    }

                    Estudante estudante = new Estudante(nomeEstudante, 0, confiancaInicial);
                    estudante.setCaracteristica(caracteristica); // Supondo que voc� tenha ou v� criar esse setter

                    digitando("Ol�, " + estudante.getNome() + ". Voc� se encontra em um labirinto que reflete seus desafios internos.", 20);
                    digitando("Sua confian�a atual �: " + estudante.getPontosDeConfianca(), 20);
                    digitando("Colete 'Pequenas Conquistas' para aumentar sua confian�a e enfrente 'Pensamentos Negativos'.", 20);

                    Labirinto labirinto = new Labirinto(8);
                    labirinto.gerarLabirinto();

                    digitando("O labirinto foi gerado. A explora��o come�a agora!", 20);

                    // Simula intera��es com conquistas e perigos (voc� pode adaptar conforme a mec�nica)
                    PequenaConquista conquista = labirinto.encontrarPequenaConquistaNaPosicao(3);
                    if (conquista != null) {
                        digitando("Voc� encontrou uma Pequena Conquista! " + conquista.getNome(), 40);
                        if (caracteristica.equals("maturidade")) {
                            estudante.adicionarPequenaConquista(conquista);
                            estudante.adicionarConfianca(5); // b�nus extra
                            digitando("Sua maturidade permitiu absorver ainda mais dessa conquista. +5 de confian�a extra!", 30);
                        } else {
                            estudante.adicionarPequenaConquista(conquista);
                        }
                      
                        estudante.adicionarPequenaConquista(conquista);
                        labirinto.removerPequenaConquista(conquista);
                        digitando("Confian�a atual: " + estudante.getPontosDeConfianca(), 20);
                    }

                    PensamentoNegativo pensamento = labirinto.encontrarPensamentoNegativoNaPosicao(4);
                    if (pensamento != null) {
                        if (caracteristica.equals("ansiedade")) {
                            pensamento.aumentarImpactoConfianca();
                        }
                        digitando(pensamento.efeito(estudante), 20);
                        digitando("Confian�a atual: " + estudante.getPontosDeConfianca(), 20);
                    }

                    digitando("\nLembre-se, " + estudante.getNome() + ", cada passo aqui � um passo em dire��o a reconhecer seu valor.", 50);
                    digitando("Foco, resili�ncia e autocompaix�o ser�o seus guias.", 50);

                    //aqui come�a o jogo msm
                    int posAtual = estudante.getLocalizacao();
                    boolean jogoAtivo = true;

                    while (jogoAtivo) {
                        labirinto.visualizarLabirinto(estudante);
                        digitando("\nVoc� est� na posi��o " + posAtual + ". O que deseja fazer?", 30);
                        System.out.println("1 - Cima");
                        System.out.println("2 - Baixo");
                        System.out.println("3 - Esquerda");
                        System.out.println("4 - Direita");
                        System.out.println("5 - Sair");

                        System.out.print("Escolha sua a��o: ");
                        int acao = sc.nextInt();
                        sc.nextLine();

                        int novaPos = posAtual;

                        switch (acao) {
                            case 1:
                                novaPos = posAtual - labirinto.getTamanho(); // andar "para frente" - subir linha
                                break;
                            case 2:
                                novaPos = posAtual + labirinto.getTamanho(); // andar "para tr�s" - descer linha
                                break;
                            case 3:
                                novaPos = posAtual - 1; // andar para esquerda - diminuir coluna
                                break;
                            case 4:
                                novaPos = posAtual + 1; // andar para direita - aumentar coluna
                                break;
                            case 5:
                                digitando("Voc� decidiu sair da jornada. At� a pr�xima!", 40);
                                jogoAtivo = false;
                                continue;
                            default:
                                digitando("Op��o inv�lida. Tente novamente.", 30);
                                continue;
                        }

                        // Verifica se novaPos � v�lida
                        if (novaPos < 0 || novaPos >= labirinto.getTamanho() * labirinto.getTamanho() || !labirinto.salaLiberada(novaPos)) {
                            digitando("Voc� bateu numa parede invis�vel do seu medo. N�o � poss�vel seguir por aqui.", 40);
                            continue;
                        }

                        posAtual = novaPos;
                        estudante.setLocalizacao(posAtual);

                        // Verificar se tem pequena conquista na nova posi��o
                         conquista = labirinto.encontrarPequenaConquistaNaPosicao(posAtual);
                        if (conquista != null) {
                            digitando("Voc� encontrou uma Pequena Conquista! " , 40);
                            
                            estudante.adicionarPequenaConquista(conquista);
                            labirinto.removerPequenaConquista(conquista);
                            digitando("Sua confian�a aumentou para: " + estudante.getPontosDeConfianca(), 30);
                        }

                        // Verificar se tem pensamento negativo
                         pensamento = labirinto.encontrarPensamentoNegativoNaPosicao(posAtual);
                        if (pensamento != null) {
                            digitando("Um pensamento negativo surgiu em sua mente...", 40);
                            digitando(pensamento.efeito(estudante), 40);
                            digitando("Sua confian�a agora �: " + estudante.getPontosDeConfianca(), 30);
                        }

                        // Verificar se tem perigo
                        Perigo perigo = labirinto.encontrarPerigoNaPosicao(posAtual);
                        if (perigo != null) {
                            digitando("Voc� se depara com um perigo: " + perigo.getDescricao(), 40);
                            // Exemplo de impacto do perigo: diminui confian�a
                            estudante.diminuiConfianca(perigo.getImpacto());
                            digitando("O perigo abalou sua confian�a para: " + estudante.getPontosDeConfianca(), 30);
                        }

                        // Voc� pode adicionar condi��o para terminar o jogo (confian�a zero ou sair do labirinto)
                        if (estudante.getPontosDeConfianca() <= 0) {
                            digitando("Sua confian�a chegou a zero. O labirinto interno ficou muito dif�cil... Mas nunca desista de voc�!", 50);
                            jogoAtivo = false;
                        }
                    }

                    break;

                case 2:
                    digitando("Saindo do jogo. Lembre-se da sua for�a! At� a pr�xima!", 50);
                    sc.close();
                    return;

                default:
                    digitando("Op��o inv�lida. Tente novamente.", 50);
            }
        }
    }
}